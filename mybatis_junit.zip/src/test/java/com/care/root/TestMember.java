package com.care.root;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.care.root.member.controller.MemberController;
import com.care.root.member.service.MemberService;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {"classpath:testMember.xml"} )
public class TestMember {
	@Autowired MemberController mc; //auto를 통해서 객체가 자동적으로 등록이 됨
	@Autowired MemberService ms;
	
	@Test
	public void testMc() {
		System.out.println("---mc => " + mc );
		assertNotNull(mc);//해당하는 객체가 null값인지 아닌지 알려주는 역할임 
	}
	
	@Test
	public void testMs() {
		assertNotNull(ms);//해당하는 객체가 null값인지 아닌지 알려주는 역할임 
	}

}
