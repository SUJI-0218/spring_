package com.care.root.member.service;

public interface MemberService {

}
