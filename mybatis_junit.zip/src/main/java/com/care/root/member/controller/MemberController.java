package com.care.root.member.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MemberController {
	public MemberController() {
		System.out.println("---mc---");
	}

}
