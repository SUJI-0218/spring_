package com.care.root.member.dao;

public interface MemberDAO {

}
