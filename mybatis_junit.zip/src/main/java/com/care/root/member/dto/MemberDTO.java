package com.care.root.member.dto;

public class MemberDTO {

}
